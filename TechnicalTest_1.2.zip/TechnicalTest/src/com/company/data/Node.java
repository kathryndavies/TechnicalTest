package com.company.data;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Represents a Tree Node
 */
public class Node {

    private String value;
    private Node parent;
    private ArrayList<Node> children;
    private static Logger LOGGER = Logger.getLogger(Node.class.getName());

    /**
     * Creates Node with a given value.
     * @param value value of node.
     */
    public Node(String value) {
        this.value = value;
        this.parent = null;
        this.children = new ArrayList<>();
        LOGGER.log(Level.INFO, "Created new node: " + this.value);
    }

    public void addChild(Node childNode) {
        childNode.setParent(this);
        this.children.add(childNode);
        LOGGER.log(Level.INFO, "Added Child Node " + childNode.value + " to " + this.value);
    }

    private void setParent(Node node) {
        this.parent = node;
    }

    public ArrayList<Node> getChildren() {
        return this.children;
    }

    public String getValue() {
        return this.value;
    }
}
