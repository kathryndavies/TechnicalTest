package com.company.processors;

import com.company.data.Node;
import com.company.data.Tree;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Represents a Data Processor
 */
public class DataProcessor {

    private Tree tree;
    private HashMap<String, HashSet<String>> dataSet;
    private static final String REGEX = "->";
    private String initialNodeValue = "";
    private static Logger LOGGER = Logger.getLogger(DataProcessor.class.getName());

    /**
     * Creates a DataProcessor and instantiates
     * the dataset and tree.
     */
    public DataProcessor() {
        this.dataSet = new HashMap<>();
        this.tree = new Tree(new Node("root"));
    }

    /**
     * Splits a line up and adds values to dataset.
     * @param string line that will be added to the dataset
     */
    public void addLineToDataset(String string) {

        String[] tokens = tokenize(string, REGEX);

        if (this.dataSet.containsKey(tokens[0])) {
            this.dataSet.get(tokens[0]).add(tokens[1]);
        }
        else {
            HashSet<String> children = new HashSet<>();
            children.add(tokens[1]);
            this.dataSet.put(tokens[0], children);
        }
    }

    /**
     * Splits string into an array of strings based on a regex value.
     * @param string the string to split up.
     * @param regex the regex value to split at.
     * @return array of split strings.
     */
    private String[] tokenize(String string,String regex) {
        String[] tokens = string.split(regex);
        return tokens;
    }

    /**
     * Populates tree.
     * @throws Exception if unable to find initial node.
     */
    public void populateTree() throws Exception {

        findFirstNode();
        Node initialNode = new Node(this.initialNodeValue);

        this.tree.getRootNode().addChild(initialNode);
        addAllChildNodes(initialNode);
    }

    /**
     * Adds all child nodes found in dataset to a given node.
     * @param node the node to which children will be added.
     */
    private void addAllChildNodes(Node node) {

        if (this.dataSet.get(node.getValue()) != null) {
            for (String child : this.dataSet.get(node.getValue())) {
                Node childNode = new Node(child);
                node.addChild(childNode);
                addAllChildNodes(childNode);
            }
        }
    }

    /**
     * Identifies the first node to add. This will be a node that
     * does not have any dependencies - therefore it is not
     * found in any of the child nodes.
     * @throws Exception if unable to find initial node.
     */
    private void findFirstNode() throws Exception {

        for (String parent : this.dataSet.keySet()) {

            boolean parentFoundInChildren = false;

            for (HashSet<String> children : this.dataSet.values()) {
                if (children.contains(parent)) {
                    parentFoundInChildren = true;
                    break;
                }
            }
            if (!parentFoundInChildren) {
                this.initialNodeValue = parent;
                break;
            }
        }
        if (this.initialNodeValue.equals("")) {
            LOGGER.log(Level.INFO, "Invalid Input: Unable to find initial node.");
            throw new Exception("Invalid Input: Unable to find initial node.");
        }
    }

    /**
     * Breadth-first traversal of tree:
     * Starting with root node, print value of all nodes at
     * current level, until all node values have been printed.
     */
    public void traverseTree() {

        List<TreeSet<String>> output = new ArrayList<>();

        LinkedList<Node> queue = new LinkedList<>();
        queue.offer(this.tree.getRootNode());

        while (!queue.isEmpty()) {

            TreeSet<String> children = new TreeSet<>();

            int size = queue.size();

            for (int i = 0; i < size; i++) {

                Node currentNode = queue.poll();

                if (currentNode != null) {
                    for (Node child : currentNode.getChildren()) {
                        children.add(child.getValue());
                        queue.offer(child);
                    }
                }
            }
            output.add(children);
        }

        for (TreeSet<String> listOfChildren : output) {
            printFormattedLine(listOfChildren);
        }
    }

    /**
     * Converts a given line to a StringBuffer, and prints
     * to console.
     * @param lineToPrint
     */
    private void printFormattedLine(TreeSet<String> lineToPrint) {

        int count = lineToPrint.size();

        for (String string : lineToPrint) {

            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append(string);

            if (count != 1) {
                stringBuffer.append(", ");
            }
            count--;
            System.out.print(stringBuffer);
        }
        System.out.println();
    }
}
