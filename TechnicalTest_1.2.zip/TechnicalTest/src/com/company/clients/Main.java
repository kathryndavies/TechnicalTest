package com.company.clients;

import com.company.processors.DataProcessor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * This program determines in which order to complete a set of tasks.
 * The program reads an input file that lists an item on each line.
 * Each line consists of a dependency and the task that it is dependent on it.
 * The dependency and task will be separated by an arrow (denoted by "->").
 */
public class Main {

    public static void main(String[] args) {

        DataProcessor dataProcessor = new DataProcessor();

        String currentDirectory = System.getProperty("user.dir");
        String fileSeparator = System.getProperty("file.separator");

        String file = currentDirectory + fileSeparator + "resources" + fileSeparator + "input.txt";

        BufferedReader inputStream = null;

        try {
            FileReader fileReader = new FileReader(file);
            inputStream = new BufferedReader(fileReader);

            String currentLine;

            while ((currentLine = inputStream.readLine()) != null) {
                dataProcessor.addLineToDataset(currentLine);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try {
            dataProcessor.populateTree();
        } catch (Exception e) {
            e.printStackTrace();
        }
        dataProcessor.traverseTree();
    }
}
