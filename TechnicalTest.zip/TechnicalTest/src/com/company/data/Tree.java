package com.company.data;

/**
 * Represents a Tree for storing and traversing Nodes.
 */
public class Tree {

    private Node rootNode;

    /**
     * Creates a tree with a root node.
     * @param rootNode the root node to set for this class.
     */
    public Tree(Node rootNode) {
        this.rootNode = rootNode;
    }

    /**
     * Gets root node.
     * @return root node.
     */
    public Node getRootNode() {
        return rootNode;
    }
}
